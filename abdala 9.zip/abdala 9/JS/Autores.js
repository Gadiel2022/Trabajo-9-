class Autor {
    constructor(nombre, apellido, pais, obraFamosa, anoPublicacion, edadPublicacion) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.pais = pais;
        this.obraFamosa = obraFamosa;
        this.anoPublicacion = anoPublicacion;
        this.edadPublicacion = edadPublicacion;
    }
}

const autores = [
    new Autor("Mario", "Vargas Llosa", "Perú", "La ciudad y los perros", 1963, 27),
    new Autor("Octavio", "Paz", "México", "El laberinto de la soledad", 1950, 36),
    new Autor("Gabriela", "Mistral", "Chile", "Desolación", 1922, 33),
    new Autor("Pablo", "Neruda", "Chile", "Veinte poemas de amor y una canción desesperada", 1924, 20),
    new Autor("Jorge", "Amado", "Brasil", "Gabriela, clavo y canela", 1958, 46),
    new Autor("Luisa", "Valenzuela", "Argentina", "El lugar del deseo", 1990, 52),
    new Autor("Roberto", "Bolaño", "Chile", "Los detectives salvajes", 1998, 45),
    new Autor("César", "Vallejo", "Perú", "Trilce", 1922, 30)
];

document.write("<table border='1'><tr>");
document.write("<th colspan='6'>Lista de Autores</th></tr>");
document.write("<tr><th>Nombre</th>");
document.write("<th>Apellido</th>");
document.write("<th>País</th>");
document.write("<th>Obra Famosa</th>");
document.write("<th>Año de Publicación</th>");
document.write("<th>Edad de Publicación</th></tr>");
autores.forEach(autor => {
    document.write("<tr>");
    document.write(`<td>${autor.nombre}</td>`);
    document.write(`<td>${autor.apellido}</td>`);
    document.write(`<td>${autor.pais}</td>`);
    document.write(`<td>${autor.obraFamosa}</td>`);
    document.write(`<td>${autor.anoPublicacion}</td>`);
    document.write(`<td>${autor.edadPublicacion}</td>`);
    document.write("</tr>");
});

document.write("<table border='1'><tr>");
document.write("<th colspan='3'>Autores Argentinos</th></tr>");
document.write("<tr><th>Nombre</th>");
document.write("<th>Apellido</th>");
document.write("<th>Obra Famosa</th></tr>");
autores.forEach(autor => {
    if (autor.pais === "Argentina") {
        document.write("<tr>");
        document.write(`<td>${autor.nombre}</td>`);
        document.write(`<td>${autor.apellido}</td>`);
        document.write(`<td>${autor.obraFamosa}</td>`);
        document.write("</tr>");
    }
});

let sumaEdades = 0;
autores.forEach(autor => {
    sumaEdades += autor.edadPublicacion;
});
const edadPromedio = sumaEdades / autores.length;
document.write(`Edad promedio de publicación: ${edadPromedio.toFixed(2)}`);

document.write("<table border='1'><tr>");
document.write("<th colspan='4'>Autores que publicaron entre 1960 y 1980</th></tr>");
document.write("<tr><th>Nombre</th>");
document.write("<th>Apellido</th>");
document.write("<th>Obra Famosa</th>");
document.write("<th>Año de Publicación</th></tr>");
autores.forEach(autor => {
    if (autor.anoPublicacion >= 1960 && autor.anoPublicacion <= 1980) {
        document.write("<tr>");
        document.write(`<td>${autor.nombre}</td>`);
        document.write(`<td>${autor.apellido}</td>`);
        document.write(`<td>${autor.obraFamosa}</td>`);
        document.write(`<td>${autor.anoPublicacion}</td>`);
        document.write("</tr>");
    }
});
